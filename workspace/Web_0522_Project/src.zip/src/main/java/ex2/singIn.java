package ex2;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import org.apache.tomcat.util.json.JSONParser;

/**
 * Servlet implementation class singIn
 */
@WebServlet("/singIn")
public class singIn extends HttpServlet {
	private static final long serialVersionUID = 1L;
//	const Obj{
//		name : ""
//		email : ""
//		phone : ""
//		country : ""
//		date : ""			
//		days : "1900/01/01" 
//		activities : ""		
//	}
       
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String country = request.getParameter("country");
		String date = request.getParameter("date");
		String days = request.getParameter("days");
		String activities = request.getParameter("activities");	
		
		response.sendRedirect("index.jsp");
	}

}
