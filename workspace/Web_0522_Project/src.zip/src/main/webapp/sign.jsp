<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@include file="header.jsp"%>
<main class="contents">
	<form class="custom-form" action="singIn" method="post">
		<h2>회원 가입</h2>		
		
		<label for="name">아이디 : </label>
		<input type="text" id="id" name="name" required>		
		
		<label for="email">이메일 : </label>
		<input type="email" id="email" name="email" required>		
		
		<label for="phone">연락처 : </label>
		<input type="tel" id="phone" name="phone" required>		
		
		<label for="country">여행 희망 국가</label>
		<select id="country" name="country">
			<option value="일본">일본</option>
			<option value="중국">중국</option>
			<option value="미국">미국</option>
			<option value="영국">영국</option>		
		</select>

		<label for="date">여행 희망 날짜</label>		
		<input type="date" id="date" name="date">
		
		<label for="days">여행 기간</label>
		<select id="days" name="days">
			<option value="2박3일">2박 3일</option>
			<option value="4박5일">4박 5일</option>
			<option value="9박10일">9박 10일</option>
			<option value="기타">기타</option>		
		</select>
		
		<label for="activities">희망 액티비티</label>
		<textarea id="activities" name="activities"
		rows="4"
		placeholder="예: 패러글라이딩, 요트 체험, 올레길 트레킹 등"></textarea>
		<button type="submit">신청하기</button>		
	</form>
</main>
<!-- footer jsp 파일 포함 -->
<%@include file="footer.jsp"%>